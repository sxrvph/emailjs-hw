let emailInput = document.querySelector(`#email_input`)
let verificationCodeInput = document.querySelector(`#verification_code_input`)
let sendEmailButton = document.querySelector(`#send_email_button`)
let loginButton = document.querySelector(`#login_button`)

let randomCode = null




sendEmailButton.addEventListener(`click`, () => {

    randomCode = Math.floor(Math.random() * 10000)

    var templateParams = {
        code: randomCode,
        to_email: emailInput.value

    }

    emailjs.send(`service_hvlyyqg`,`template_j25o0f8`, templateParams)
        .then(function(response){
            console.log(`succes`, response.status, response.text)
        }, function(error) {
            console.log(`failed`, error)
        })
            
})

loginButton.addEventListener(`click`, () => {
    if(randomCode == verificationCodeInput.value){
        console.log(`secciess authorization`)
    } else {
        console.log(`unsuccess authorization`)
    }
})